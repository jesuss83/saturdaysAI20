﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql;
using System.Configuration;
using System.IO;

namespace classifierTest
{
    public struct Box
    {
        public string ImgPath { get; set; }
        public string Label { get; set; }
        public int CenterX { get; set; }
        public int CenterY { get; set; }
        public int CenterPoint { get; set; }
        public int CenterPointScalated { get; set; }


    }
    public partial class Form1 : Form
    {
        private Dictionary<string, string> labels = new Dictionary<string, string>();
        private Dictionary<string, string> selectedBoxes = new Dictionary<string, string>();
        private int pointX = 0;
        private int pointY = 0;

        public Form1()
        {
            InitializeComponent();
            InitBoxes();
        }

        private void InitBoxes()
        {
            selectedBoxes = new Dictionary<string, string>();
            cmbBoxSets.SelectedItem = "AllBoxes";
            int totalBoxes = GetTotalRecords(cmbBoxSets.SelectedItem.ToString());

            int offset = 24;
            int totalPages = (totalBoxes / offset)+1;

            lblTotalRecords.Text = totalBoxes.ToString();

            for(int i = 0;i<totalPages;i++)
            {
                cmbPages.Items.Add((i + 1).ToString());
            }

            if (totalPages>0)
                cmbPages.SelectedItem = "1";

            SetPage("AllBoxes", 24, 1);
        }

        private void UpdateSets()
        {
            string category = null;
            if (cmbCategories.SelectedItem != null)
                category = cmbCategories.SelectedItem.ToString();
                
            selectedBoxes = new Dictionary<string, string>();            
            int totalBoxes = GetTotalRecords(cmbBoxSets.SelectedItem.ToString(),category);

            int offset = 24;
            int totalPages = (totalBoxes / offset) + 1;

            lblTotalRecords.Text = totalBoxes.ToString();

            for (int i = 0; i < totalPages; i++)
            {
                cmbPages.Items.Add((i + 1).ToString());
            }

            if (totalPages > 0)
                cmbPages.SelectedItem = "1";

            SetPage(cmbBoxSets.SelectedItem.ToString(), 24, 1);
        }

        private void SetPage(string option,int offset, int page)
        {
            List<Box> boxes = new List<Box>();
            selectedBoxes = new Dictionary<string, string>();
            switch(option)
            {
                case "AllBoxes":
                    {
                        boxes = LoadAllBoxes(offset, page);
                        break;
                    }
                case "NonLabeled":
                    {
                        boxes = LoadNonLabeled(offset, page);
                        break;
                    }
                case "Category": {
                        
                        if (cmbCategories.SelectedItem == null)
                        {
                            MessageBox.Show("Select category");
                            return;
                        }

                        string category = cmbCategories.SelectedItem.ToString();

                        boxes = LoadAByCategory(offset, page, category);
                        break;
                    }
                

            }

            ShowBoxes(boxes);
        }

        private void NextPage()
        {
            if (cmbBoxSets.SelectedItem == null)
            {
                MessageBox.Show("Select option");
                return;
            }

            string option = cmbBoxSets.SelectedItem.ToString();
            int page = Convert.ToInt32(cmbPages.SelectedItem.ToString());

            if (page <= cmbPages.Items.Count)
            {
                page++;
            }
            else return;

            cmbPages.SelectedItem = page.ToString();
            SetPage(option,24, page);

        }

        private void GoToPage()
        {
            string option = cmbBoxSets.SelectedItem.ToString();
            int page = Convert.ToInt32(cmbPages.SelectedItem.ToString());

        }

        private int GetTotalRecords(string option, string category=null)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            string sql = string.Empty;

            /*AllBoxes
Labeled
NonLabeled
Boxed
NonBoxed
New
Completed
Category*/

            switch (option) {
                case "AllBoxes":
                    sql = string.Format("select count(*) as total from boxes2");
                    break;
                case "Labeled":
                    sql = string.Format("select count(*) as total from boxes2 where Label1!=''");
                    break;
                case "NonLabeled":
                    sql = string.Format("select count(*) as total from boxes2 where Label1 is null");
                    break;
                case "Category":
                    sql = string.Format("select count(*) from boxes2 WHERE Label1='{0}'",category);
                    break;
            }

            mySqlConn.Open();
            MySqlCommand getTotalBoxesCommand = new MySqlCommand(sql, mySqlConn);            

            int totalBoxes = Convert.ToInt32(getTotalBoxesCommand.ExecuteScalar());
                       
                        
            mySqlConn.Close();

            return totalBoxes;

        }

        private List<Box> LoadAllBoxes(int totalRecords, int page)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            int offset = totalRecords * (page-1);
            string sqlSelect = string.Format("select * from boxes2 limit {0} offset {1}", totalRecords.ToString(), offset);
            MySqlCommand getBoxesCommand = new MySqlCommand(sqlSelect, mySqlConn);
            List<Box> boxes = new List<Box>();

            mySqlConn.Open();
            MySqlDataReader dr = getBoxesCommand.ExecuteReader();

            while(dr.Read())
            {
                Box box = new Box() { ImgPath = dr["Img"].ToString(), Label = dr["Label1"].ToString(), CenterX = Convert.ToInt32(dr["CenterX"] != DBNull.Value ? dr["CenterX"] : -1), CenterY = Convert.ToInt32(dr["CenterY"] != DBNull.Value ? dr["CenterY"] : -1), CenterPoint = Convert.ToInt32(dr["CenterPointOriginal"] != DBNull.Value ? dr["CenterPointOriginal"] : -1) };

                boxes.Add(box);
            }

            dr.Close();
            mySqlConn.Close();

            return boxes;

        }

        private List<Box> LoadAByCategory(int totalRecords, int page, string category)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            int offset = totalRecords * (page - 1);
            string sqlSelect = string.Format("select * from boxes2 WHERE Label1='{2}' limit {0} offset {1}", totalRecords.ToString(), offset,category);
            MySqlCommand getBoxesCommand = new MySqlCommand(sqlSelect, mySqlConn);
            List<Box> boxes = new List<Box>();

            mySqlConn.Open();
            MySqlDataReader dr = getBoxesCommand.ExecuteReader();

            while (dr.Read())
            {
                Box box = new Box() { ImgPath = dr["Img"].ToString(), Label = dr["Label1"].ToString(), CenterX = Convert.ToInt32(dr["CenterX"] != DBNull.Value ? dr["CenterX"] : -1), CenterY = Convert.ToInt32(dr["CenterY"] != DBNull.Value ? dr["CenterY"] : -1), CenterPoint = Convert.ToInt32(dr["CenterPointOriginal"] != DBNull.Value ? dr["CenterPointOriginal"] : -1) };

                boxes.Add(box);
            }

            dr.Close();
            mySqlConn.Close();

            return boxes;

        }

        private List<Box> LoadNonLabeled(int totalRecords, int page)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            int offset = totalRecords * (page - 1);
            string sqlSelect = string.Format("select * from boxes2 where CenterPointOriginal is null limit {0} offset {1}", totalRecords.ToString(), offset);
            MySqlCommand getBoxesCommand = new MySqlCommand(sqlSelect, mySqlConn);
            List<Box> boxes = new List<Box>();

            mySqlConn.Open();
            MySqlDataReader dr = getBoxesCommand.ExecuteReader();

            while (dr.Read())
            {
                Box box = new Box() { ImgPath = dr["Img"].ToString(), Label = dr["Label1"].ToString(), CenterX = Convert.ToInt32(dr["CenterX"] != DBNull.Value ? dr["CenterX"] : -1), CenterY = Convert.ToInt32(dr["CenterY"] != DBNull.Value ? dr["CenterY"] : -1) };

                boxes.Add(box);
            }

            dr.Close();
            mySqlConn.Close();

            return boxes;

        }

        private void RemoveBoxes()
        {
            List<string> imgs = new List<string>();

            foreach(Control control in this.Controls)
            {
                if (control.Tag != null)
                {

                    if (control.Tag.ToString().Contains("pbox"))
                    {
                        imgs.Add(control.Name);
                    }
                }
            }

            foreach(string img in imgs)
            {
                this.Controls.RemoveByKey(img);
            }
        }

        private void ShowBoxes(List<Box> boxes)
        {
            PictureBox pbox = new PictureBox();
            pbox.Height = 190;
            pbox.Width = 288;
            string imgPath  = "C:\\models\\ryuboxes\\training\\"; // "C:\\tf\\stills\\";
            string imgUrl = imgPath;
            Bitmap img = null;
            int index = 0;

            RemoveBoxes();

            for (int i = 0;i<4; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    if (index >= boxes.Count) break;
                    Box currentBox = boxes[index];
                    imgUrl = imgPath + currentBox.ImgPath;
                    img = new Bitmap(imgUrl);
                    pbox = new PictureBox();
                    pbox.Image = img;
                    pbox.Location = new Point((j * 310), 50 + (i * 230));
                    pbox.Height = 190; //220;
                    pbox.Width = 288; //300;
                    index++;
                    pbox.Name = currentBox.ImgPath;
                    pbox.Tag = "pbox-" + currentBox.ImgPath;
                    pbox.Click += pboxClick;
                    pbox.MouseMove += Pbox_MouseMove;

                    Label lblSet = new Label();
                    lblSet.Name = index.ToString();
                    lblSet.Location = new Point(10,10);                    
                    lblSet.Text = "Set";
                    lblSet.BackColor = Color.Yellow;
                    lblSet.Visible = false;
                    lblSet.Font = new Font(FontFamily.GenericMonospace, 12, FontStyle.Italic);

                    Label lblTooltip = new Label();
                    lblTooltip.Width = 100;
                    lblTooltip.Name = index.ToString();
                    lblTooltip.Location = new Point(10, 10);
                    lblTooltip.Width = 230;
                    lblTooltip.Height = 20;
                    lblTooltip.Text = currentBox.ImgPath;
                    lblTooltip.BackColor = Color.Orange;
                    lblTooltip.Visible = true;
                    lblTooltip.Font = new Font(FontFamily.GenericMonospace, 12, FontStyle.Italic);

                    Label label = new Label();
                    label.Name = index.ToString();
                    label.Location = new Point(50, 200);
                    label.Text = currentBox.Label;
                    label.BackColor = Color.Red;
                    label.ForeColor = Color.White;
                    label.Visible = false;
                    label.Font = new Font(FontFamily.GenericMonospace, 12, FontStyle.Italic);

                    Label lblPoint = new Label();
                   
                    lblPoint.Name = index.ToString();
                    lblPoint.Width = 10;
                    lblPoint.Height = 10;
                    lblPoint.Location = new Point(currentBox.CenterX, currentBox.CenterY);
                    lblPoint.Text = "X";// String.Format("{0},{1},{2}",currentBox.CenterX!=-1?currentBox.CenterX.ToString():string.Empty,currentBox.CenterY!=-1?currentBox.CenterY.ToString():string.Empty,currentBox.CenterPoint!=-1?currentBox.CenterPoint.ToString():string.Empty);
                    lblPoint.BackColor = Color.Red;
                    lblPoint.ForeColor = Color.White;
                    lblPoint.Visible = currentBox.CenterX != -1 && currentBox.CenterY != -1;
                    lblPoint.Font = new Font(FontFamily.GenericMonospace, 12, FontStyle.Italic);


                    pbox.Controls.Add(lblSet);
                    pbox.Controls.Add(lblTooltip);
                    pbox.Controls.Add(label);
                    pbox.Controls.Add(lblPoint);
                    this.Controls.Add(pbox);
                    

                }
            }

        }

        private void Pbox_MouseMove(object sender, MouseEventArgs e)
        {
            pointX = e.X;
            pointY = e.Y;

        }

        private void UpdateSelected(string name, bool visible)
        {
            if (visible && !selectedBoxes.ContainsKey(name))
            {
                selectedBoxes.Add(name, name);
            }

            if (!visible && selectedBoxes.ContainsKey(name))
            {
                selectedBoxes.Remove(name);
            }
        }

        private void pboxClick(object sender, EventArgs e)
        {            
            ((Label)((PictureBox)sender).Controls[0]).Visible = !((Label)((PictureBox)sender).Controls[0]).Visible;

            bool visible = ((Label)((PictureBox)sender).Controls[0]).Visible;
            string name = ((PictureBox)sender).Name;
            int point = (pointY * 288) + pointX;

            //UpdateSelected(name,visible);

            SavePoint(name, pointX, pointY, point);
            ((Label)((PictureBox)sender).Controls[3]).Visible = true;
            ((Label)((PictureBox)sender).Controls[3]).Location = new Point(pointX, pointY);
            ((Label)((PictureBox)sender).Controls[3]).Text = "X:" + pointX.ToString() + "Y: " + pointY.ToString() + "Point: " + point;


        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.F1:
                    {
                        SetLabels();
                        break;
                    }
            }
        }

        private List<string> GetFiles()
        {
            string path = "C:\\models\\ryuboxes\\training"; //"C:\\tf\\stills";

            return Directory.GetFiles(path).ToList();

        }

        private void UpdateImages()
        {
            LoadImages();
            _UpdateImages();
        }
        private void _UpdateImages()
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            MySqlCommand getNewFilesCommand = new MySqlCommand("select Filename from files where Filename not in (select Img from boxes2)", mySqlConn);

            mySqlConn.Open();
            MessageBox.Show("Getting new files");
            MySqlDataReader dr = getNewFilesCommand.ExecuteReader();
            List<string> insertsSql = new List<string>();
            
            int total = 0;
            
            while(dr.Read())
            {
                string fileName = dr["Filename"].ToString();
                string[] info = fileName.Split('.');
                string label1 = info[0];

                string sql = String.Format("INSERT INTO boxes2 (Img,Label1, Labeled,Boxed,Status,ImportedDate,IsDeleted,Created,Modified) VALUES ('{0}','{1}',1,0,'New',NOW(),0,NOW(),NOW())", fileName,label1);
                insertsSql.Add(sql);
            }

            dr.Close();

            foreach(string sql in insertsSql)
            {
                MySqlCommand insertFileCmd = new MySqlCommand(sql, mySqlConn);
                insertFileCmd.ExecuteNonQuery();
                total++;
            }

            mySqlConn.Close();
            
            MessageBox.Show("Finished importing images: " + total.ToString());
        }

        private void LoadImages()
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            MySqlCommand mySqlCommand = new MySqlCommand("DELETE FROM files",mySqlConn);

            mySqlConn.Open();
            MessageBox.Show("Deleting files");
            mySqlCommand.ExecuteNonQuery();
            List<string> files = GetFiles();
            
            MessageBox.Show(files.Count() +  " files");
            
            MessageBox.Show("Inserting files");

            foreach(string file in files)
            {
                string fileName = new FileInfo(file).Name;
                string sql = String.Format("INSERT INTO files (filename) VALUES ('{0}')", fileName);
                MySqlCommand insertFileCmd = new MySqlCommand(sql, mySqlConn);
                insertFileCmd.ExecuteNonQuery();
            }

            mySqlConn.Close();
            MessageBox.Show("Finished");

        }

        private void SetLabels()
        {
            int index = 0;

            if (cmbCategories.SelectedItem == null) {
                MessageBox.Show("Select label");
                return;
            }


            if (String.IsNullOrEmpty(cmbCategories.SelectedItem.ToString())) 
            {
                MessageBox.Show("Select label");
                return;
            }

            if (selectedBoxes.Count() == 0)
            {
                MessageBox.Show("Select boxes");
                return;
            }

            string selectedLabel = cmbCategories.SelectedItem.ToString();

            foreach(string img in selectedBoxes.Keys)
            {
                SaveLabel(img, selectedLabel);
            }

            foreach (Control control in this.Controls)
            {
                if (selectedBoxes.ContainsKey(control.Name))
                {
                    PictureBox box = (PictureBox)control;
                    Label lblSet = (Label)box.Controls[0];
                    Label lblLabel = (Label)box.Controls[2];

                    lblSet.Visible = false;
                    lblLabel.Text = selectedLabel;
                }

                index++;
            }

            selectedBoxes = new Dictionary<string, string>();
        }

        private void SaveLabel(string img, string label)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            
            mySqlConn.Open();
            
            string sql = String.Format("UPDATE boxes2 SET Label1 = '{0}',Status='LabelUpdated', LabeledDate=NOW(), Modified=NOW() WHERE Img = '{1}'", label,img);
            MySqlCommand updateLabelCmd = new MySqlCommand(sql, mySqlConn);
            updateLabelCmd.ExecuteNonQuery();

            mySqlConn.Close();
            
        }

        private void SavePoint(string img, int x, int y, int point)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);

            mySqlConn.Open();

            string sql = String.Format("UPDATE boxes2 SET CenterPointOriginal = {0}, CenterX={1},CenterY={2}, Modified=NOW() WHERE Img = '{3}'", point,x,y,img);
            MySqlCommand updateLabelCmd = new MySqlCommand(sql, mySqlConn);
            updateLabelCmd.ExecuteNonQuery();

            mySqlConn.Close();

        }



        private void btnRefreshImages_Click(object sender, EventArgs e)
        {
            UpdateImages();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'H')
            {
                MessageBox.Show("H");
            }
        }

        private void btnGoToPage_Click(object sender, EventArgs e)
        {
            SetLabels();
        }

        private void cmbCategories_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                    {
                        SetLabels();
                        break;
                    }
                case Keys.F2:
                    {
                        NextPage();
                        break;
                    }
                case Keys.F3:
                    {
                        UpdateSets();
                        break;
                    }
            }
        }

        private void cmbBoxSets_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSets();
        }

        private void cmbBoxSets_SelectedValueChanged(object sender, EventArgs e)
        {            
            UpdateSets();
        }

        private void cmbBoxSets_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
        }

        private void btnStats_Click(object sender, EventArgs e)
        {
            Form2 frmStats = new Form2();
            frmStats.Show();

        }

        private void btnActions_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }
    }
}
