﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Configuration;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;

namespace classifierTest
{
    public partial class Form3 : Form
    {        
        public Form3()
        {
            InitializeComponent();
        }

        private void GenRyuNoRyu()
        {
            string path = "C:\\models\\ryunoryu\\training";
            string pathLabels = "C:\\models\\ryunoryu\\ryunoryu-labels.csv";

            DirectoryInfo dirInfo = new DirectoryInfo(path);
            StreamWriter streamWriter = new StreamWriter(pathLabels);

            MessageBox.Show("Generating labels for ryuNoRyu");

            foreach (FileInfo file in dirInfo.GetFiles())
            {
                string fileName = file.Name;

                if (!fileName.Contains("_g"))
                {

                    if (fileName.Contains("ryu") || fileName.Contains("noryu"))
                    {
                        string[] fileNameInfo = fileName.Split('-');
                        string fileLabel = fileNameInfo[0];
                        string label = fileLabel == "ryu" ? "1" : "0";
                        string lineLabel = String.Format("{0},{1}", fileName, label);
                        streamWriter.WriteLine(lineLabel);
                    }

                    if (fileName.Contains("img"))
                    {
                        string label = "1";
                        string lineLabel = String.Format("{0},{1}", fileName, label);
                        streamWriter.WriteLine(lineLabel);
                    }
                }
            }

            streamWriter.Close();

            MessageBox.Show("Finished");

        }

        private void GenRyuNoRyuGray()
        {
            string path = "C:\\models\\ryunoryu\\training";
            string pathLabels = "C:\\models\\ryunoryu\\ryunoryu-labels-gray.csv";

            DirectoryInfo dirInfo = new DirectoryInfo(path);
            StreamWriter streamWriter = new StreamWriter(pathLabels);

            MessageBox.Show("Generating labels for ryuNoRyu");

            foreach (FileInfo file in dirInfo.GetFiles())
            {
                string fileName = file.Name;

                if (fileName.Contains("_g"))
                {
                    if (fileName.Contains("ryu") || fileName.Contains("noryu"))
                    {
                        string[] fileNameInfo = fileName.Split('-');
                        string fileLabel = fileNameInfo[0];
                        string label = fileLabel == "ryu" ? "1" : "0";
                        string lineLabel = String.Format("{0},{1}", fileName, label);
                        streamWriter.WriteLine(lineLabel);
                    }

                    if (fileName.Contains("img"))
                    {
                        string label = "1";
                        string lineLabel = String.Format("{0},{1}", fileName, label);
                        streamWriter.WriteLine(lineLabel);
                    }
                }
            }

            streamWriter.Close();

            MessageBox.Show("Finished");

        }

        private void GenRyuMovs()
        {
            string path = "C:\\models\\ryumovs\\training";
            string pathLabels = "C:\\models\\ryumovs\\ryumovs-labels.csv";
            string imgPath = "C:\\tf\\stills";

            DirectoryInfo dirInfo = new DirectoryInfo(path);
            StreamWriter streamWriter = new StreamWriter(pathLabels);

            MessageBox.Show("Generating labels for ryuMovs");
            
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();
            string sql = "select * from boxes WHERE Label1 is not null and Label1 != 'RyuOtro' and Label1 != 'None'";
            MySqlCommand comm = new MySqlCommand(sql, mySqlConn);
            MySqlDataReader dr = comm.ExecuteReader();
            int total = 0;

            while(dr.Read())
            {
                string img = dr["Img"].ToString();
                string label = dr["Label1"].ToString();
                string fromFile = String.Format("{0}\\{1}", imgPath, img);
                string toFile = String.Format("{0}\\{1}", path, img);
                string line = String.Format("{0},{1}", img, label);

                File.Copy(fromFile, toFile);
                streamWriter.WriteLine(line);
                total++;

            }            

            streamWriter.Close();
            dr.Close();
            mySqlConn.Close();

            MessageBox.Show("Finished: " + total + " labels");

        }

        private void btnGenerateRyuFiles_Click(object sender, EventArgs e)
        {
            GenRyuNoRyu();            
            GenRyuNoRyuGray();
        }

        private void btnGenRyuMovs_Click(object sender, EventArgs e)
        {
            GenRyuMovs();
        }

        private void btnRenameFiles_Click(object sender, EventArgs e)
        {
            string path = "C:\\models\\ryunoryu\\validation";
            string path2 = "C:\\models\\ryunoryu\\validation2";

            DirectoryInfo dir = new DirectoryInfo(path);
            int index = 0;
       
            foreach(FileInfo file in dir.GetFiles())
            {
                string fNameNew = string.Empty;
                if (file.Name.Contains("img"))
                {
                    fNameNew = String.Format("ryu.{0}.png", index.ToString());
                    File.Copy(file.FullName, path2 + "\\" + fNameNew);
                }

                if (file.Name.Contains("ryu"))
                {
                    if (!file.Name.Contains("noryu")) 
                    {
                        fNameNew = String.Format("ryu.{0}.png", index.ToString());
                        File.Copy(file.FullName, path2 + "\\" + fNameNew);
                    }

                    if (file.Name.Contains("noryu"))
                    {
                        fNameNew = String.Format("nr.{0}.png", index.ToString());
                        File.Copy(file.FullName, path2 + "\\" + fNameNew);
                    }

                }

                index++;

                

            }

            MessageBox.Show("finished copying");

        }

        private void UpdateRyuFiles()
        {
            string path = "C:\\models\\ryumovs\\training\\cropped";
            string path2 = "C:\\models\\ryunoryu\\training";

            DirectoryInfo dir = new DirectoryInfo(path);
            int index = 2724;// dir2.GetFiles().Count();

            foreach (FileInfo file in dir.GetFiles())
            {
                string fNameNew = string.Empty;
                /*if (file.Name.Contains("img"))
                {
                    fNameNew = String.Format("ryu.{0}.png", index.ToString());
                    File.Copy(file.FullName, path2 + "\\" + fNameNew);
                }*/

                if (file.Name.Contains("ryu"))
                {
                    fNameNew = String.Format("ryu.{0}.png", index.ToString());
                    File.Copy(file.FullName, path2 + "\\" + fNameNew);
                }

                index++;

            }

            MessageBox.Show("finished copying");

        }

        private void CopyToCatDir(string file, string category)
        {
            string path = "C:\\models\\ryumovs\\training\\cropped";
            string path2 = "C:\\models\\ryumovs\\training";

            string catDir = path2 + "\\" + category;
            string originalPath = path + "\\" + file;

            if (!Directory.Exists(catDir))
            {
                Directory.CreateDirectory(catDir);
            }

            if (Directory.Exists(catDir))
            {
                int totalFiles = Directory.GetFiles(catDir).Count();
                string copyFile = String.Format("{0}.{1}.png", category, totalFiles.ToString());
                string copyPath = catDir + "\\" + copyFile;

                File.Copy(originalPath, copyPath);
            }

        }
        private void CategorizeRyuFiles()
        {
            string path2 = "C:\\models\\ryumovs";
            string csv = path2 + "\\" + "ryumovs-labels.csv";


            using (StreamReader sr = new StreamReader(csv))
            {
                while (sr.Peek() >= 0)
                {
                    string line = sr.ReadLine();
                    string[] data = line.Split(',');
                    CopyToCatDir(data[0], data[1]);
                }
            }

            MessageBox.Show("finished copying");

        }

        private void btnGenRuyMovs2_Click(object sender, EventArgs e)
        {
            //UpdateRyuFiles();
            CategorizeRyuFiles();
        }

        private void _UpdatePoint(string img, int x, int y, int point, string data)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();
            string sql = String.Format("insert into dataset (Img,CenterPoint,CenterX,CenterY,dataset) VALUES ('{0}',{1},{2},{3},'{4}')", img,point,x,y,data);
            
            MySqlCommand comm = new MySqlCommand(sql, mySqlConn);
            comm.ExecuteNonQuery();
            mySqlConn.Close();
        }

        private void UpdatePoint(string img, string data)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();
            string sql = String.Format("select * from boxes2 WHERE Img = '{0}' AND CenterPointOriginal is not null ",img);
            int point = 0;
            int x = 0;
            int y = 0;
            MySqlCommand comm = new MySqlCommand(sql, mySqlConn);
            
            MySqlDataReader dr = comm.ExecuteReader();            
            
            while (dr.Read())
            {                
                point = Convert.ToInt32(dr["CenterPointOriginal"]);
                x = Convert.ToInt32(dr["CenterX"]);
                y = Convert.ToInt32(dr["CenterY"]);                

            }

            dr.Close();
            mySqlConn.Close();

            if (point != 0)
            {
                _UpdatePoint(img, x, y, point, data);
            }

        }

        private int GetPoint(string img)
        {
            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();
            string sql = String.Format("select CenterPointOriginal from boxes2 WHERE Img = '{0}' AND CenterPointOriginal is not null ", img);
            int point = 0;
            int x = 0;
            int y = 0;
            MySqlCommand comm = new MySqlCommand(sql, mySqlConn);

            MySqlDataReader dr = comm.ExecuteReader();

            while (dr.Read())
            {
                point = Convert.ToInt32(dr["CenterPointOriginal"]);
                //x = Convert.ToInt32(dr["CenterX"]);
                //y = Convert.ToInt32(dr["CenterY"]);

            }

            dr.Close();
            mySqlConn.Close();

            return point;

        }

        private void UpdateTileset()
        {
            string pathTileset = "C:\\models\\ryuboxes\\tilesetAvg.csv";            
            int total = 0;

            MessageBox.Show("Updating tileset data");                       

            using (StreamReader sr = new StreamReader(pathTileset))
            {
                while (sr.Peek() >= 0)
                {
                    string line = sr.ReadLine();
                    string[] data = line.Split(':');
                    string img = data[0];
                    string dataset = data[1];
                    UpdatePoint(img, dataset);
                    
                }
                sr.Close();
            }
            
            MessageBox.Show("Finished: " + total + " tiles");
        }

        private void GenTilesetAvg()
        {
            string pathTileset = "C:\\Users\\jesus\\tilesetAvg.csv";
            string pathTilesetUpdated = "C:\\Users\\jesus\\tilesetAvgUpdated.csv";
            int total = 0;
            List<string> headers = new List<string>();
            string hdrNames = string.Empty;

            MessageBox.Show("Get tileset avg");
            StreamWriter sw = new StreamWriter(pathTilesetUpdated);

            for (int i = 1; i <= 342; i++)
            {
                headers.Add(String.Format("\"Tile{0}\"", (i - 1).ToString()));
            }

            headers.Add("\"Center\"");

            foreach (string header in headers)
            {
                hdrNames = hdrNames + header + ",";
            }

            hdrNames = hdrNames.Remove(hdrNames.Length - 1, 1);

            sw.WriteLine(hdrNames);

            using (StreamReader sr = new StreamReader(pathTileset))
            {
                while (sr.Peek() >= 0)
                {
                    string line = sr.ReadLine();
                    string[] data = line.Split(':');
                    string img = data[0];
                    string dataset = data[1];
                    int point = GetPoint(img);
                    sw.WriteLine("{0},{1}", dataset, point.ToString());

                }
                sr.Close();
            }
            sw.Close();
            MessageBox.Show("Finished: " + total + " tiles");
        }

        private void GenTilesetAvgTesting()
        {
            string pathTileset = "C:\\Users\\jesus\\tilesetAvg.csv";
            string pathTilesetUpdated = "C:\\Users\\jesus\\tilesetAvgUpdated.csv";
            int total = 0;
            List<string> headers = new List<string>();
            string hdrNames = string.Empty;

            MessageBox.Show("Get tileset avg testing");
            StreamWriter sw = new StreamWriter(pathTilesetUpdated);            

            using (StreamReader sr = new StreamReader(pathTileset))
            {
                while (sr.Peek() >= 0)
                {
                    string line = sr.ReadLine();
                    string[] data = line.Split(':');
                    string img = data[0];
                    string dataset = data[1];
                    int point = GetPoint(img);
                    sw.WriteLine("{0},{1},{2}",img, dataset, point.ToString());

                }
                sr.Close();
            }
            sw.Close();
            MessageBox.Show("Finished: " + total + " tiles");
        }

        private void GenTileset()
        {
            string pathTileset = "C:\\models\\ryuboxes\\tilesetFull.csv";
            int total = 0;
            string img = string.Empty;
            int point = 0;
            int x = 0;
            int y = 0;
            string data = string.Empty;

            MessageBox.Show("Generating tileset data");

            StreamWriter sw = new StreamWriter(pathTileset, false);

            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();
            string sql = String.Format("select * from dataset");
            
            MySqlCommand comm = new MySqlCommand(sql, mySqlConn);

            MySqlDataReader dr = comm.ExecuteReader();

            while (dr.Read())
            {
                img = dr["Img"].ToString();
                point = Convert.ToInt32(dr["CenterPoint"]);
                x = Convert.ToInt32(dr["CenterX"]);
                y = Convert.ToInt32(dr["CenterY"]);
                data = dr["dataset"].ToString();

                string line = String.Format("{0},{1},{2},{3},{4}", img, point.ToString(), x.ToString(), y.ToString(), data);

                sw.WriteLine(line);
                total++;

            }

            dr.Close();
            mySqlConn.Close();
            
            MessageBox.Show("Finished: " + total + " files");
        }

        private void GenTilesetFromDict(Dictionary<int, string> dict, string file)
        {
            string pathTileset = "C:\\models\\ryuboxes\\" + file;
            int total = 0;
            int point = 0;
            int x = 0;
            int y = 0;
            string data = string.Empty;
            List<string> headers = new List<string>();            
            string hdrNames = string.Empty;

            MessageBox.Show("Generating tileset data from dict");

            StreamWriter sw = new StreamWriter(pathTileset, false);

            for (int i = 1; i <= 342; i++) 
            {
                headers.Add(String.Format("\"Tile{0}\"", (i - 1).ToString()));
            }

            headers.Add("\"Center\"");

            foreach (string header in headers)
            {
                hdrNames = hdrNames + header + ",";
            }

            hdrNames = hdrNames.Remove(hdrNames.Length - 1, 1);

            sw.WriteLine(hdrNames);


            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();

            foreach (string img in dict.Values)
            {
                string sql = String.Format("select * from dataset where Img = '" + img + "'");

                MySqlCommand comm = new MySqlCommand(sql, mySqlConn);

                MySqlDataReader dr = comm.ExecuteReader();

                while (dr.Read())
                {                    
                    point = Convert.ToInt32(dr["CenterPoint"]);
                    x = Convert.ToInt32(dr["CenterX"]);
                    y = Convert.ToInt32(dr["CenterY"]);
                    data = dr["dataset"].ToString();

                    //string line = String.Format("{0},{1},{2},{3},{4}", img, point.ToString(), x.ToString(), y.ToString(), data);
                    string line = String.Format("{0},{1}", data, point.ToString());
                    //16777216 

                    sw.WriteLine(line);
                    total++;

                }

                dr.Close();
                
            }

            mySqlConn.Close();
            sw.Close();
            MessageBox.Show("Finished: " + total + " files");
        }

        private Dictionary<int,string> GenTilesetDict()
        {            
            int total = 0;
            string img = string.Empty;            
            int index = 0;
            Dictionary<int, string> dict = new Dictionary<int, string>();                        

            MySqlConnection mySqlConn = new MySqlConnection(ConfigurationManager.ConnectionStrings["classifierTest.Properties.Settings.tfConnectionString"].ConnectionString);
            mySqlConn.Open();
            string sql = String.Format("select * from dataset");

            MySqlCommand comm = new MySqlCommand(sql, mySqlConn);

            MySqlDataReader dr = comm.ExecuteReader();

            while (dr.Read())
            {
                img = dr["Img"].ToString();

                dict.Add(index, img);
                
                index++;
                total++;

            }

            dr.Close();
            mySqlConn.Close();

            return dict;            
        }

        private List<int> GetRandoms(int lowerIndex, int upperIndex,int total)
        {
            Random rnd = new Random();
            List<int> randoms = new List<int>();

            do
            {
                int random = rnd.Next(lowerIndex, upperIndex - 1);
                
                if (!randoms.Contains(random))
                {
                    randoms.Add(random);                 
                }

                if (randoms.Count() >= total) return randoms;

            } while (randoms.Count() < total);

            

            return randoms;
        }



        private void GenDicts()
        {
            Dictionary<int, string> tilesetDict = GenTilesetDict();
            int total = tilesetDict.Count();
            int totalTest = 200;            

            List<int> testRandoms = GetRandoms(0, total,totalTest);            

            Dictionary<int, string> trainingDict = new Dictionary<int, string>();
            Dictionary<int, string> testDict = new Dictionary<int, string>();

            foreach (int random in testRandoms)
            {
                if (tilesetDict.ContainsKey(random))
                {
                    if (!testDict.ContainsKey(random))
                    {
                        testDict.Add(random, tilesetDict[random]);
                    }                    
                }
            }

            foreach (int index in tilesetDict.Keys)
            {
                if (!testDict.ContainsKey(index) && !trainingDict.ContainsKey(index))
                {
                    trainingDict.Add(index, tilesetDict[index]);
                }
            }




            GenTilesetFromDict(trainingDict, "training.csv");
            GenTilesetFromDict(testDict, "test.csv");

        }

        private void GenTileset2()
        {
            GenDicts();

        }


        private void btnGetTileset_Click(object sender, EventArgs e)
        {
            UpdateTileset();
        }

        private void btnGenTilesetData_Click(object sender, EventArgs e)
        {
            GenTilesetAvgTesting();
        }
    }
}
