﻿namespace classifierTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRefreshImages = new System.Windows.Forms.Button();
            this.cmbPages = new System.Windows.Forms.ComboBox();
            this.cmbBoxSets = new System.Windows.Forms.ComboBox();
            this.cmbCategories = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPrevPage = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCurrentPage = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblTotalRecords = new System.Windows.Forms.Label();
            this.btnGoToPage = new System.Windows.Forms.Button();
            this.btnStats = new System.Windows.Forms.Button();
            this.btnActions = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRefreshImages
            // 
            this.btnRefreshImages.Location = new System.Drawing.Point(13, 13);
            this.btnRefreshImages.Name = "btnRefreshImages";
            this.btnRefreshImages.Size = new System.Drawing.Size(115, 23);
            this.btnRefreshImages.TabIndex = 0;
            this.btnRefreshImages.Text = "Refresh Images";
            this.btnRefreshImages.UseVisualStyleBackColor = true;
            this.btnRefreshImages.Click += new System.EventHandler(this.btnRefreshImages_Click);
            // 
            // cmbPages
            // 
            this.cmbPages.FormattingEnabled = true;
            this.cmbPages.Location = new System.Drawing.Point(461, 15);
            this.cmbPages.Name = "cmbPages";
            this.cmbPages.Size = new System.Drawing.Size(121, 21);
            this.cmbPages.TabIndex = 1;
            // 
            // cmbBoxSets
            // 
            this.cmbBoxSets.FormattingEnabled = true;
            this.cmbBoxSets.Items.AddRange(new object[] {
            "NonLabeled",
            "Boxed",
            "NonBoxed",
            "New",
            "Completed",
            "Category",
            "AllBoxes",
            "Labeled"});
            this.cmbBoxSets.Location = new System.Drawing.Point(334, 15);
            this.cmbBoxSets.Name = "cmbBoxSets";
            this.cmbBoxSets.Size = new System.Drawing.Size(121, 21);
            this.cmbBoxSets.TabIndex = 2;
            this.cmbBoxSets.SelectedIndexChanged += new System.EventHandler(this.cmbBoxSets_SelectedIndexChanged_1);
            this.cmbBoxSets.SelectedValueChanged += new System.EventHandler(this.cmbBoxSets_SelectedValueChanged);
            // 
            // cmbCategories
            // 
            this.cmbCategories.FormattingEnabled = true;
            this.cmbCategories.Items.AddRange(new object[] {
            "RyuCaido1",
            "RyuCaido2",
            "RyuKick1",
            "RyuPunch1",
            "RyuThrowing1",
            "RyuGrabbing1",
            "RyuGrabbing2",
            "RyuGrabbing3",
            "RyuSaltando1",
            "RyuSaltando2",
            "RyuMaroma1",
            "RyuMaroma2",
            "RyuCayendo1",
            "RyuFlyingKick1",
            "RyuBajando1",
            "RyuStanding1",
            "RyuHariuken1",
            "RyuHariuken2",
            "RyuCunclillasFrente1",
            "RyuCunclillasFrente2",
            "RuyCunclilllasDerecha1",
            "RyuCunclillasDerecha2",
            "RyuCunclillasEspalda1",
            "RyuLowerKick1",
            "RyuCunclillasParandose1",
            "RyuStandin2",
            "RyuStanding3",
            "RyuStanding4",
            "RyuJumping1",
            "RyuJumping2",
            "RyuJumping3",
            "RyuMaroma3",
            "RyuBajandoGolpeado1",
            "RyuRodilla",
            "RyuGolpeado1",
            "RyuGolpeado2",
            "RyuOtro",
            "None",
            "RyuSaltandoAtras",
            "RyuLowerKick2",
            "RyuWin",
            "RyuFliyingPunch",
            "RyuStanding1FlipDer",
            "RyuSaltando1FlipDer",
            "RyuFlyingKick1FlipDer"});
            this.cmbCategories.Location = new System.Drawing.Point(461, 982);
            this.cmbCategories.Name = "cmbCategories";
            this.cmbCategories.Size = new System.Drawing.Size(272, 21);
            this.cmbCategories.TabIndex = 3;
            this.cmbCategories.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbCategories_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(332, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Options";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(131, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(458, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Pages";
            // 
            // btnPrevPage
            // 
            this.btnPrevPage.Location = new System.Drawing.Point(656, 13);
            this.btnPrevPage.Name = "btnPrevPage";
            this.btnPrevPage.Size = new System.Drawing.Size(75, 23);
            this.btnPrevPage.TabIndex = 7;
            this.btnPrevPage.Text = "Prev Page";
            this.btnPrevPage.UseVisualStyleBackColor = true;
            // 
            // btnNextPage
            // 
            this.btnNextPage.Location = new System.Drawing.Point(750, 13);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(75, 23);
            this.btnNextPage.TabIndex = 8;
            this.btnNextPage.Text = "Next Page";
            this.btnNextPage.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(845, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Current Page:";
            // 
            // lblCurrentPage
            // 
            this.lblCurrentPage.AutoSize = true;
            this.lblCurrentPage.Location = new System.Drawing.Point(923, 18);
            this.lblCurrentPage.Name = "lblCurrentPage";
            this.lblCurrentPage.Size = new System.Drawing.Size(0, 13);
            this.lblCurrentPage.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(956, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Total records:";
            // 
            // lblTotalRecords
            // 
            this.lblTotalRecords.AutoSize = true;
            this.lblTotalRecords.Location = new System.Drawing.Point(1034, 18);
            this.lblTotalRecords.Name = "lblTotalRecords";
            this.lblTotalRecords.Size = new System.Drawing.Size(0, 13);
            this.lblTotalRecords.TabIndex = 12;
            // 
            // btnGoToPage
            // 
            this.btnGoToPage.Location = new System.Drawing.Point(588, 13);
            this.btnGoToPage.Name = "btnGoToPage";
            this.btnGoToPage.Size = new System.Drawing.Size(45, 23);
            this.btnGoToPage.TabIndex = 13;
            this.btnGoToPage.Text = "Go";
            this.btnGoToPage.UseVisualStyleBackColor = true;
            this.btnGoToPage.Click += new System.EventHandler(this.btnGoToPage_Click);
            // 
            // btnStats
            // 
            this.btnStats.Location = new System.Drawing.Point(1166, 12);
            this.btnStats.Name = "btnStats";
            this.btnStats.Size = new System.Drawing.Size(75, 23);
            this.btnStats.TabIndex = 14;
            this.btnStats.Text = "Stats";
            this.btnStats.UseVisualStyleBackColor = true;
            this.btnStats.Click += new System.EventHandler(this.btnStats_Click);
            // 
            // btnActions
            // 
            this.btnActions.Location = new System.Drawing.Point(134, 15);
            this.btnActions.Name = "btnActions";
            this.btnActions.Size = new System.Drawing.Size(75, 23);
            this.btnActions.TabIndex = 15;
            this.btnActions.Text = "Actions";
            this.btnActions.UseVisualStyleBackColor = true;
            this.btnActions.Click += new System.EventHandler(this.btnActions_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1269, 1015);
            this.Controls.Add(this.btnActions);
            this.Controls.Add(this.btnStats);
            this.Controls.Add(this.btnGoToPage);
            this.Controls.Add(this.lblTotalRecords);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblCurrentPage);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.btnPrevPage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbCategories);
            this.Controls.Add(this.cmbBoxSets);
            this.Controls.Add(this.cmbPages);
            this.Controls.Add(this.btnRefreshImages);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRefreshImages;
        private System.Windows.Forms.ComboBox cmbPages;
        private System.Windows.Forms.ComboBox cmbBoxSets;
        private System.Windows.Forms.ComboBox cmbCategories;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPrevPage;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCurrentPage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblTotalRecords;
        private System.Windows.Forms.Button btnGoToPage;
        private System.Windows.Forms.Button btnStats;
        private System.Windows.Forms.Button btnActions;
    }
}

