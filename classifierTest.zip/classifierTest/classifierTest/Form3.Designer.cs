﻿namespace classifierTest
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerateRyuFiles = new System.Windows.Forms.Button();
            this.btnGenRyuMovs = new System.Windows.Forms.Button();
            this.btnRenameFiles = new System.Windows.Forms.Button();
            this.btnGenRuyMovs2 = new System.Windows.Forms.Button();
            this.btnUpdateTileset = new System.Windows.Forms.Button();
            this.btnGenTilesetData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGenerateRyuFiles
            // 
            this.btnGenerateRyuFiles.Location = new System.Drawing.Point(372, 15);
            this.btnGenerateRyuFiles.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenerateRyuFiles.Name = "btnGenerateRyuFiles";
            this.btnGenerateRyuFiles.Size = new System.Drawing.Size(196, 64);
            this.btnGenerateRyuFiles.TabIndex = 0;
            this.btnGenerateRyuFiles.Text = "Generate RyuNoRyu Files";
            this.btnGenerateRyuFiles.UseVisualStyleBackColor = true;
            this.btnGenerateRyuFiles.Click += new System.EventHandler(this.btnGenerateRyuFiles_Click);
            // 
            // btnGenRyuMovs
            // 
            this.btnGenRyuMovs.Location = new System.Drawing.Point(372, 116);
            this.btnGenRyuMovs.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenRyuMovs.Name = "btnGenRyuMovs";
            this.btnGenRyuMovs.Size = new System.Drawing.Size(196, 64);
            this.btnGenRyuMovs.TabIndex = 1;
            this.btnGenRyuMovs.Text = "Generate RyuMovs Files";
            this.btnGenRyuMovs.UseVisualStyleBackColor = true;
            this.btnGenRyuMovs.Click += new System.EventHandler(this.btnGenRyuMovs_Click);
            // 
            // btnRenameFiles
            // 
            this.btnRenameFiles.Location = new System.Drawing.Point(372, 203);
            this.btnRenameFiles.Margin = new System.Windows.Forms.Padding(4);
            this.btnRenameFiles.Name = "btnRenameFiles";
            this.btnRenameFiles.Size = new System.Drawing.Size(196, 64);
            this.btnRenameFiles.TabIndex = 2;
            this.btnRenameFiles.Text = "Rename Files";
            this.btnRenameFiles.UseVisualStyleBackColor = true;
            this.btnRenameFiles.Click += new System.EventHandler(this.btnRenameFiles_Click);
            // 
            // btnGenRuyMovs2
            // 
            this.btnGenRuyMovs2.Location = new System.Drawing.Point(372, 286);
            this.btnGenRuyMovs2.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenRuyMovs2.Name = "btnGenRuyMovs2";
            this.btnGenRuyMovs2.Size = new System.Drawing.Size(196, 64);
            this.btnGenRuyMovs2.TabIndex = 3;
            this.btnGenRuyMovs2.Text = "Gen Ruy Movs Category";
            this.btnGenRuyMovs2.UseVisualStyleBackColor = true;
            this.btnGenRuyMovs2.Click += new System.EventHandler(this.btnGenRuyMovs2_Click);
            // 
            // btnUpdateTileset
            // 
            this.btnUpdateTileset.Location = new System.Drawing.Point(372, 371);
            this.btnUpdateTileset.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateTileset.Name = "btnUpdateTileset";
            this.btnUpdateTileset.Size = new System.Drawing.Size(196, 64);
            this.btnUpdateTileset.TabIndex = 4;
            this.btnUpdateTileset.Text = "Update Tileset";
            this.btnUpdateTileset.UseVisualStyleBackColor = true;
            this.btnUpdateTileset.Click += new System.EventHandler(this.btnGetTileset_Click);
            // 
            // btnGenTilesetData
            // 
            this.btnGenTilesetData.Location = new System.Drawing.Point(372, 460);
            this.btnGenTilesetData.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenTilesetData.Name = "btnGenTilesetData";
            this.btnGenTilesetData.Size = new System.Drawing.Size(196, 64);
            this.btnGenTilesetData.TabIndex = 5;
            this.btnGenTilesetData.Text = "Gen Tileset Data";
            this.btnGenTilesetData.UseVisualStyleBackColor = true;
            this.btnGenTilesetData.Click += new System.EventHandler(this.btnGenTilesetData_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 604);
            this.Controls.Add(this.btnGenTilesetData);
            this.Controls.Add(this.btnUpdateTileset);
            this.Controls.Add(this.btnGenRuyMovs2);
            this.Controls.Add(this.btnRenameFiles);
            this.Controls.Add(this.btnGenRyuMovs);
            this.Controls.Add(this.btnGenerateRyuFiles);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGenerateRyuFiles;
        private System.Windows.Forms.Button btnGenRyuMovs;
        private System.Windows.Forms.Button btnRenameFiles;
        private System.Windows.Forms.Button btnGenRuyMovs2;
        private System.Windows.Forms.Button btnUpdateTileset;
        private System.Windows.Forms.Button btnGenTilesetData;
    }
}